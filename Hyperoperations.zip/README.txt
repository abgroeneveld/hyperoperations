HYPEROPERATIONS PACKAGE
VERSION 0.1

For instructions on using the package, please see HyperoperationsManual.pdf.

If you are curious about how the package works, feel free to read the source
code of the package, Hyperoperations.m.  The file s25 contains a critical
function of the superlogarithm; the manual has more information, as well as
instructions for generating other approximations.

If you find anything that needs correcting, from a typo to a bug to a serious
mathematical blunder, feel free to tell me by emailing abgroene@mtu.edu.